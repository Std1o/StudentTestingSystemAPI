create view rating_view as
select `testing_system`.`tests`.`course_id`      AS `course_id`,
       `testing_system`.`results`.`user_id`      AS `user_id`,
       `testing_system`.`users`.`username`       AS `username`,
       `testing_system`.`users`.`email`          AS `email`,
       `testing_system`.`results`.`score`        AS `score`,
       `testing_system`.`results`.`max_score`    AS `max_score`,
       `testing_system`.`results`.`passing_time` AS `passing_time`
from `testing_system`.`users`
         join `testing_system`.`results`
         join `testing_system`.`tests`
where ((`testing_system`.`users`.`id` = `testing_system`.`results`.`user_id`) and
       (`testing_system`.`tests`.`id` = `testing_system`.`results`.`test_id`));

