create view detailed_result as
select `testing_system`.`results`.`user_id` AS `user_id`,
       `testing_system`.`users`.`username`  AS `username`,
       `testing_system`.`users`.`email`     AS `email`,
       `testing_system`.`results`.`score`   AS `score`,
       `testing_system`.`results`.`test_id` AS `test_id`
from `testing_system`.`users`
         join `testing_system`.`results`
where (`testing_system`.`users`.`id` = `testing_system`.`results`.`user_id`);

