create
    definer = root@localhost function isCourseOwner(userId int, courseId int) returns tinyint(1) deterministic
BEGIN
            DECLARE isOwner BOOLEAN;
            SELECT is_owner INTO isOwner FROM participants WHERE user_id=userId AND course_id=courseId;
            RETURN isOwner;
        END;

