create
    definer = root@localhost function isCourseOwner(userId int, courseId int) returns tinyint(1) deterministic
BEGIN
            DECLARE isOwner BOOLEAN;
            SET isOwner = (SELECT is_owner FROM participants WHERE user_id=userId AND course_id=courseId);
            RETURN isOwner;
        END;

