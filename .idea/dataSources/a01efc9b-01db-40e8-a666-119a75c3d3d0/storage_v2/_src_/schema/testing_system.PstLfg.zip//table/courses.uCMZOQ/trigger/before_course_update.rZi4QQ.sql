create definer = root@localhost trigger before_course_update
    before update
    on courses
    for each row
BEGIN
           IF NEW.id != OLD.id THEN
               SET NEW='id cannot be changed';
           END IF;
        END;

