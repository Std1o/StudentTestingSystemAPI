CREATE VIEW rating_view AS SELECT results.user_id, users.username, users.email, results.score, results.max_score, results.test_id, results.passing_time 
FROM results, users, tests 
WHERE users.id = results.user_id AND tests.id = results.test_id;

