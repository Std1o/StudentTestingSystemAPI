CREATE TRIGGER before_course_update BEFORE UPDATE on courses
            WHEN NEW.id != OLD.id
                BEGIN 
                    SELECT RAISE(ABORT, 'id cannot be changed');
                END;

